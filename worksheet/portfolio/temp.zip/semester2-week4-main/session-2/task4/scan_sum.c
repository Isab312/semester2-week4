
#include <stdio.h>

int main( void ) {

    // define suitable data

    // use scanf to read from the terminal
    // print the output from scanf and the data values 

    return 0;
}